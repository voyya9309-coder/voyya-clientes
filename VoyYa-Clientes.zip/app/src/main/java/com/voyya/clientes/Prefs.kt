package com.voyya.clientes

import android.content.Context

/** Sesión del cliente guardada en el teléfono para que el servicio funcione con la app cerrada. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("voyya_cliente", Context.MODE_PRIVATE)

    fun save(c: Context, userId: String, url: String, key: String) {
        sp(c).edit()
            .putString("uid", userId)
            .putString("url", url.trimEnd('/'))
            .putString("key", key)
            .apply()
    }

    fun clear(c: Context) {
        sp(c).edit().remove("uid").remove("url").remove("key").remove("notif").apply()
    }

    fun userId(c: Context): String? = sp(c).getString("uid", null)
    fun url(c: Context): String? = sp(c).getString("url", null)
    fun key(c: Context): String? = sp(c).getString("key", null)

    /** Recuerda los pedidos ya avisados (aunque el servicio se reinicie) para no repetir el sonido. Devuelve true si es nuevo. */
    @Synchronized
    fun markNotified(c: Context, id: String): Boolean {
        val cur = HashSet(sp(c).getStringSet("notif", emptySet()) ?: emptySet())
        if (cur.contains(id)) return false
        if (cur.size > 200) cur.clear()
        cur.add(id)
        sp(c).edit().putStringSet("notif", cur).apply()
        return true
    }

    fun batteryAsked(c: Context): Boolean = sp(c).getBoolean("bat_asked", false)
    fun setBatteryAsked(c: Context) = sp(c).edit().putBoolean("bat_asked", true).apply()
}

/** Dice si la pantalla de la app está abierta. */
object AppState {
    @Volatile
    var foreground: Boolean = false
}
