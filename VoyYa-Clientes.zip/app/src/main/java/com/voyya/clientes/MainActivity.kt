package com.voyya.clientes

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.os.PowerManager
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null
    private val downloadIds = mutableSetOf<Long>()

    private val dlReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id == -1L || !downloadIds.remove(id)) return
            try {
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.query(DownloadManager.Query().setFilterById(id)).use { cur ->
                    if (cur.moveToFirst()) {
                        val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        if (st == DownloadManager.STATUS_SUCCESSFUL) {
                            val uri = dm.getUriForDownloadedFile(id)
                            if (uri != null) instalarApk(uri)
                        } else {
                            Toast.makeText(this@MainActivity, "No se pudo descargar la aplicación", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = filePathCallback
            filePathCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        }

    private val permsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val cb = geoCallback
            if (cb != null) {
                cb.invoke(geoOrigin, hasLocation(), true)
                geoCallback = null
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OrderService.createChannels(this)
        ContextCompat.registerReceiver(
            this, dlReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED
        )

        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "VoyYaNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                abrirEnlace(request.url)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (hasLocation()) {
                    callback.invoke(origin, true, true)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    permsLauncher.launch(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                }
            }

            // window.open(...) (por ejemplo el enlace de WhatsApp) se abre fuera de la app
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val temp = WebView(view.context)
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        abrirEnlace(request.url)
                        v.destroy()
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }

        web.setDownloadListener { url, _, _, _, _ -> abrirEnlace(Uri.parse(url)) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })

        requestStartupPermissions()

        val hash = pedidoId(intent)?.let { "#pedido=$it" } ?: ""
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html$hash")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = pedidoId(intent)
        if (id != null) {
            web.evaluateJavascript("try{track('$id')}catch(e){}", null)
        }
    }

    private fun pedidoId(i: Intent?): String? =
        i?.getStringExtra("pedido_id")?.takeIf { Regex("^[A-Za-z0-9-]{1,64}$").matches(it) }

    override fun onResume() {
        super.onResume()
        AppState.foreground = true
        web.onResume()
    }

    override fun onPause() {
        AppState.foreground = false
        web.onPause()
        super.onPause()
    }

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestStartupPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (!hasLocation()) {
            need += Manifest.permission.ACCESS_FINE_LOCATION
            need += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (need.isNotEmpty()) permsLauncher.launch(need.toTypedArray())
    }

    private fun esApk(u: Uri): Boolean {
        val t = u.toString()
        return t.contains(".apk", ignoreCase = true) || t.contains("/storage/v1/object/public/apks/")
    }

    private fun abrirEnlace(u: Uri) {
        if (esApk(u)) descargarApk(u) else openExternal(u)
    }

    /** Descarga la APK con el gestor de descargas de Android y, al terminar, abre el instalador. */
    private fun descargarApk(u: Uri) {
        try {
            val base = (u.lastPathSegment ?: "app.apk").replace(Regex("[^A-Za-z0-9._-]"), "_")
            val nombre = if (base.endsWith(".apk", ignoreCase = true)) base else "$base.apk"
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), nombre).delete()
            val req = DownloadManager.Request(u)
                .setTitle(nombre)
                .setDescription("Descargando aplicación")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, nombre)
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            downloadIds.add(dm.enqueue(req))
            Toast.makeText(this, "Descargando… al terminar se abrirá la instalación", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            openExternal(u)
        }
    }

    private fun instalarApk(uri: Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "Abre la descarga desde la notificación para instalarla", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(dlReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
        }
    }

    /** Pide una sola vez que la app no sea limitada por el ahorro de batería (necesario para recibir pedidos con la app cerrada). */
    private fun askBatteryOnce() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        if (Prefs.batteryAsked(this)) return
        Prefs.setBatteryAsked(this)
        AlertDialog.Builder(this)
            .setTitle("Para recibir pedidos con la app cerrada")
            .setMessage("Permite que ¡VoyYa! funcione sin restricciones de batería. Así el teléfono te avisará cuando tu repartidor esté en camino aunque tengas la pantalla apagada.")
            .setPositiveButton("Permitir") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    /** Puente que usa la página (window.VoyYaNative) para activar o apagar el servicio de pedidos. */
    inner class Bridge {
        @JavascriptInterface
        fun start(userId: String, url: String, key: String) {
            try {
                val anterior = Prefs.userId(applicationContext)
                Prefs.save(applicationContext, userId, url, key)
                if (!OrderService.running || anterior != userId) OrderService.start(applicationContext)
                runOnUiThread {
                    try { askBatteryOnce() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {
            }
        }

        @JavascriptInterface
        fun stop() {
            try {
                val habia = Prefs.userId(applicationContext) != null
                Prefs.clear(applicationContext)
                if (habia && OrderService.running) OrderService.stop(applicationContext)
            } catch (_: Throwable) {
            }
        }
    }
}
