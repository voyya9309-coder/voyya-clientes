plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.voyya.clientes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.voyya.clientes"
        minSdk = 24
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0"
    }

    // Firma fija: así cada APK nueva se instala ENCIMA de la anterior sin desinstalar.
    signingConfigs {
        create("voyya") {
            storeFile = file("voyya.keystore")
            storePassword = "voyya2026"
            keyAlias = "voyya"
            keyPassword = "voyya2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("voyya")
        }
        debug {
            signingConfig = signingConfigs.getByName("voyya")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
